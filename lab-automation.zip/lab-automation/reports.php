<?php
include 'redirect.php';
include 'db.php';

$test_data = [];
$sql = "SELECT status,count(*) AS counts FROM tests GROUP BY status";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $test_data[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Lab Automation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        canvas {
            max-width: 100%;
            max-height: 300px;
        }
        .container {
            margin: 100px 20px 20px 300px;
            flex-grow: 1;
            padding: 15px;
            background-color: #f4f4f9;
            overflow-x: hidden;
        }
        .download-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        .download-btn:hover {
            background-color: #0056b3;
        }
        .sidebar {
    width: 250px;
    background-color: #ffffff;
    padding: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    align-content: center;
    height: 100%;
    top: 0;
    left: 0;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bolder;
    padding: 10px 12px;
    display: block;
    transition: 0.2s linear;
}

.sidebar ul li a:hover {
    background-color: #007bff;
    border-radius: 7px;
    color: white;
}

.dashboard {
    display: flex;
}
p.log-out{
    width: 75%;
    margin: 10px 10px 10px 10px;
    position: absolute;
    bottom: 30px;
    color: #333;
    font-size: 17px;
    font-weight: bolder;
    padding: 10px 15px 10px 20px;
    transition: 0.2s linear;
    border-radius: 7px;
    cursor: pointer;
}
p.log-out:hover{
    background-color: #007bff;
    color: white;
}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include 'header.php';?>
    <div class="dashboard"></div>
    <?php include_once 'sidebar.php';?>
    <div class="container">
        <div class="card">
            <h2>Test Overview</h2>
            <canvas id="Chart1"></canvas>
        </div>
        <div class="card">
            <h2>Download PDF Report</h2>
            <button class="download-btn" onclick="downloadPDF()">Download Report</button>
        </div>
    </div>
    </div>
    <script>
        // Data for the chart
        const testData = <?php echo json_encode($test_data); ?>;
        const labels = testData.map(data => data.status);
        const counts = testData.map(data => data.counts);

        // Chart.js configuration
        const ctx = document.getElementById('Chart1').getContext('2d');
        const testChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Tests Status',
                    data: counts,
                    backgroundColor: '#007bff',
                    borderColor: '#0056b3',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: true },
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Function to download the report as PDF
        function downloadPDF(e) {
            window.location.href = 'generate_pdf.php';
        }
    </script>
</body>
</html>
<?php
?>