<?php
include 'db.php';

    $test_id = $_GET['id'];

    $sql = "DELETE FROM `tests` WHERE `test_id`='$test_id'";
    $result = $conn->query($sql);
    if ($conn->error) {
        die('An unexpected Error Occured');
    }else{
        header('Location: tests.php');
    }
?>