<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f9;
        color: #333;
    }
    .container {
        max-width: 600px;
        margin: 50px auto;
        padding: 20px;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #007bff;
    }
    form label {
        display: block;
        margin: 10px 0 5px;
        color: #555;
    }
    form input, form select, form textarea {
        width: 90%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #f9f9f9;
        color: #333;
        margin-bottom: 20px;
    }
    form input:focus, form select:focus, form textarea:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
    form button {
        background-color: #007bff;
        color: #ffffff;
        border: none;
        padding: 10px 15px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
    }
    form button:hover {
        background-color: #0056b3;
    }
    a {
        color: #007bff;
        display: block;
        margin: 10px;
        text-decoration: none;
        font-weight: bolder;
    }
    a button{
        margin: 10px 0px;
        background-color: #007bff;
        padding: 10px 5px;
        color: white;
        font-weight: bolder;
        width: 15%;
    }
</style>
</head>
<body>
    <div class="container">
        <h2>New Product Details</h2>
        <form action="" method="POST">
            <a href="products.php"><button type="button"><i class="fa-solid fa-arrow-left"></i> Back</button></a>
            <label for="product_name">Product Name</label>
            <input type="text" id="product_name" name="product_name" required>
            
            <label for="revision">Version</label>
            <input type="text" id="revision" name="revision" required>
            
            <label for="manufacturing_date">Manufacturing Date</label>
            <input type="date" id="manufacturing_date" name="manufacturing_date" required>
            
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="5"></textarea>
            
            <button type="submit">Add Product</button>
        </form>
    </div>
</body>
</html>
<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $revision = $_POST['revision'];
    $manufacturing_date = $_POST['manufacturing_date'];
    $description = $_POST['description'];
    $created_at = date('Y-m-d H:i:s');

    $sql = "SELECT MAX(product_id) AS product_id FROM tests";
    $result = $conn->query($sql);


    $row = string($result->fetch_assoc()+1);

    $sql = "INSERT INTO products (product_id,product_name, revision, manufacturing_date,description, created_at,'user_id')
            VALUES ('$row','$product_name', '$revision', '$manufacturing_date', '$description', '$created_at','".$_SESSION['user_id']."'";

    if ($conn->query($sql) === TRUE) {
        echo "Product added successfully! <a href='add_product.php'>Add another product</a> or <a href='index.php'>Go back to Dashboard</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
