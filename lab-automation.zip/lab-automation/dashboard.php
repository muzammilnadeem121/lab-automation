<?php include 'redirect.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Lab Automation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=light_mode" />
    <?php
        include 'db.php';
        // Fetch Tests Data
        $tests_sql = "SELECT * FROM tests WHERE 1";
        $tests_result = $conn->query($tests_sql);

        // Fetch Employees Data
        $employees_sql = "SELECT * FROM employees WHERE 1";
        $employees_result = $conn->query($employees_sql);

        $active_emp_sql = "SELECT * FROM employees WHERE `status`='Active'";
        $active_emp_result = $conn->query($active_emp_sql);

        $products_sql = "SELECT * FROM products WHERE 1";
        $products_result = $conn->query($products_sql);

        $users_sql = "SELECT * FROM users WHERE 1";
        $users_result = $conn->query($users_sql);
    ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            margin: 100px 20px 20px 300px;
            flex-grow: 1;
            padding: 15px;
            background-color: #f4f4f9;
            overflow-x: hidden;
        }
        .card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            overflow-y: auto;
            max-height: 700px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        .dashboard {
        display: flex;
    }
    </style>
</head>
<body>
<?php include 'header.php';?>
    <div class="dashboard">
    <?php include_once 'sidebar.php';?>
    <div class="container">
    <div class="card">
        <h2>Lab Overview</h2>
        <table>
            <tbody>
                <tr>
                    <th>Total Employees:</th>
                    <td><?php echo $employees_result->num_rows ?></td>
                    <th>Total Users:</th>
                    <td><?php echo $users_result->num_rows ?></td>
                    <th>Tests Performed:</th>
                    <td><?php echo $tests_result->num_rows ?></td>
                </tr>
                <tr>
                    <th>Active Employees:</th>
                    <td><?php echo $active_emp_result->num_rows ?></td>
                    <th>Tests Passed:</th>
                    <td><?php $a = $conn->query("SELECT * FROM `tests` WHERE `status`='Passed'"); echo $a->num_rows; ?></td>
                    <th>Tests Failed:</th>
                    <td><?php $a = $conn->query("SELECT * FROM `tests` WHERE `status`='Failed'"); echo $a->num_rows; ?></td>
                </tr>
            </tbody>
        </table>
    </div>

        <!-- Tests Overview -->
        <div class="card">
            <h2>Tests Overview</h2>
            <table>
                <thead>
                    <tr>
                        <th>Test Name</th>
                        <th>Product</th>
                        <th>Criteria</th>
                        <th>Status</th>
                        <th>Tested At</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $tests_result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $row['test_type'];?> test</td>
        <td>
            <?php 
                // Fetch product name only once
                $product_sql = "SELECT product_name FROM products WHERE product_id = " . $row['product_id'];
                $product_result = $conn->query($product_sql);
                if ($product_result->num_rows > 0) {
                    $product_row = $product_result->fetch_assoc();
                    echo $product_row['product_name'];
                }
            ?>
        </td>
        <td><?php echo $row['criteria']; ?></td>
        <td><?php echo $row['status']; ?></td>
        <td><?php echo $row['tested_at']; ?></td>
        <td><?php echo $row['remarks']; ?></td>
    </tr>
<?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Active Employees -->
        <div class="card">
            <h2>Employees</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $employees_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['first_name'] . " " . $row['last_name']; ?></td>
                            <td><?php echo $row['designation']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['phone_number']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>Products</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Version</th>
                        <th>MFG Date</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $products_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['product_id']; ?></td>
                            <td><?php echo $row['product_name']; ?></td>
                            <td><?php echo $row['revision']; ?></td>
                            <td><?php echo $row['manufacturing_date']; ?></td>
                            <td><?php echo $row['description']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
</body>
</html>