<?php
session_start();
include_once 'db.php';

function timeAgo($datetime) {
    $time_difference = time() - strtotime($datetime);
    if ($time_difference < 60) {
        return 'just now';
    } elseif ($time_difference < 3600) {
        return floor($time_difference / 60) . 'm ago';
    } elseif ($time_difference < 86400) {
        return floor($time_difference / 3600) . 'h ago';
    } elseif ($time_difference < 2592000) {
        return floor($time_difference / 86400) . 'd ago';
    } else {
        return date('M d, Y', strtotime($datetime));
    }
}

if(isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM `messages` WHERE `id` = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $message = $result->fetch_assoc();
    } else {
        die('No feedback found!');
    }
} else {
    // Fetch all feedbacks for the table
    $sql = "SELECT * FROM `messages` ORDER BY `id` DESC";
    $result = $conn->query($sql);

    if (!$result || $result->num_rows == 0) {
        die('No feedbacks yet!');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks - Lab Automation</title>
    <?php include 'links.php'; ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .dashboard {
            display: flex;
        }
        .container {
            margin: 100px 20px 20px 300px;
            flex-grow: 1;
            padding: 15px;
            background-color: #f4f4f9;
            overflow-x: hidden;
        }
        .card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th{
            border-bottom: 1px solid black;
            padding: 10px;
            text-align: left;
        }
        table td {
            border-bottom: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        tbody tr {
            transition: 0.3s background;
        }
        tbody tr:hover {
            cursor: pointer;
            background-color: #eee;
        }
        .feedback-detail {
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 2px solid #ddd;
        }
        button{
            border: none;
            border-radius: 100%;
            background-color: #007bff;
            color: white;
            font-weight: bolder;
            cursor: pointer;
            height: 30px;
            width: 30px;
            text-align: center;
            align-content: center;
        }
    </style>
</head>
<body>
    <?php include_once 'header.php'; ?>
    <div class="dashboard">
        <?php include_once 'sidebar.php'; ?>
        <div class="container">
            <div class="card">
                <?php if (isset($message)) { ?>
                    <div class="feedback-detail">
                        <a href="feedbacks.php"><button><i class="fa-solid fa-arrow-left"></i></button></a>
                        <h2>Feedback from <?php echo htmlspecialchars($message['name']); ?></h2>
                        <p><strong>From:</strong> <?php echo htmlspecialchars($message['email']); ?></p>
                        <p><strong>Subject:</strong> <?php echo htmlspecialchars($message['subject']); ?></p>
                        <p><strong>Time:</strong> <?php echo timeAgo($message['submitted_at']); ?></p>
                        <hr>
                        <p><strong>Message:</strong></p>
                        <p><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                    </div>
                <?php } else { ?>
                    <h2>User Feedbacks</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>From</th>
                                <th>Subject</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <tr class="trow" data-target="feedbacks.php?id=<?php echo $row['id']; ?>">
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                    <td><?php echo timeAgo($row['submitted_at']); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } ?>
            </div>
        </div>
    </div>
</body>
<script>
    document.querySelectorAll('.trow').forEach(element => {
        element.addEventListener('click', function () {
            var target = element.dataset.target;
            location.href = target;
        });
    });
</script>
</html>
