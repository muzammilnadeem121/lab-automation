<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['pfp']) && $_FILES['pfp']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/profile-pics/';
        $fileName = basename($_FILES['pfp']['name']);
        $fileExtension = pathinfo($_FILES['pfp']['name'], PATHINFO_EXTENSION);
        $targetPath = $uploadDir . $_SESSION['user_id'].'.png';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Move the uploaded file
        if (move_uploaded_file($_FILES['pfp']['tmp_name'], $targetPath)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
    } else {
        echo json_encode(['success' => false]);
    }
}
?>
