<style>
    .Active{
        background-color: #007bff;
        color: white !important;
    }
    .fa-circle-user::after{
        content: "";
        background-color:rgba(0, 0, 0, 0.44);
        position: absolute;
        left: 75px;
        text-align: center;
        top: 3px;
        width: 40%;
        border-radius: 360px;
        height: 88%;
        transition:;
        color: white;
        font-size: 50px;
        align-content: center;
        opacity: 0;
        transition: 0.2s opacity;
        z-index: 10000000;
    }
    .fa-circle-user:hover::after{
        opacity: 1;
    }
    .fa-circle-user{
        color: #74C0FC;
        cursor:pointer;
    }
    .sidebar {
    transition: 0.2s ease-in-out;
    width: 250px;
    background-color: #ffffff;
    padding: 15px;
    box-shadow: 10px 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    align-content: center;
    height: 100%;
    top: 0;
    left: 0;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bolder;
    padding: 10px 12px;
    display: block;
    transition: 0.2s linear;
    border-radius: 7px;
}

.sidebar ul li a:hover {
    background-color: #007bff;
    color: white;
}
p.log-out{
    width: 80%;
    margin: 10px 10px 10px 0px;
    position: absolute;
    bottom: 30px;
    color: #333;
    font-size: 17px;
    font-weight: bolder;
    padding: 10px 15px 10px 20px;
    transition: 0.2s linear;
    border-radius: 7px;
    cursor: pointer;
}
p.log-out:hover{
    background-color: #007bff;
    color: white;
}
.logo{
    cursor:pointer;position:absolute;top: 5px;left: 75px;z-index:200;width:100px;height:100px;border-radius:100%;
}
@media (max-width: 900px) {
        .sidebar{
            left: -300px;
        }
        .container{
            margin-left: 40px;
        }
    }
</style>
<div class="sidebar" id="sidebar">
        <div class="wrapper" style="width:100%;text-align:center;">
            <div class="pfp" id="pfp" style="font-size:100px;position:relative;">
                <img class="logo" src="./Uploads/profile-pics/<?php echo $_SESSION['user_id'];?>.png">
                <i class="fa-solid fa-circle-user"></i>
            </div>
        </div>
        <center><p><strong>User Name: </strong><?php echo $_SESSION["username"]; ?></p></center>
        <ul>
            <li><a class="item" href="dashboard.php"><i class="fas fa-dashboard"></i> Dashboard</a></li>
            <li><a class="item" href="tests.php"><i class="fas fa-tasks"></i> Tests Overview</a></li>
            <li><a class="item" href="products.php"><i class="fas fa-box"></i> Products</a></li>
            <li><a class="item" href="reports.php"><i class="fas fa-chart-line"></i> Reports</a></li>
            <li><a class="item" href="feedbacks.php"><i class="fa-solid fa-comment"></i> Feedbacks</a></li>
        </ul>
        <p class="log-out" id="logout"><i class="fa-solid fa-right-from-bracket"></i> LogOut</p>
</div>
<script>

var logout = document.getElementById('logout');
logout.addEventListener('click', () => {
    location.href = "logout.php";
});

var items = document.querySelectorAll('.item');

window.addEventListener('DOMContentLoaded', () => {
    // Set activePage to 'dashboard.php' on initial page load if not already set in sessionStorage
    if (!sessionStorage.getItem('activePage')) {
        sessionStorage.setItem('activePage', 'dashboard.php');
    }

    // Get the active page from sessionStorage
    const activePath = sessionStorage.getItem('activePage');

    // Highlight the appropriate item
    if (activePath) {
        items.forEach(item => {
            if (item.href === activePath) {
                item.classList.add('Active');
            } else {
                item.classList.remove('Active');
            }
        });
    }
});

// Add click event listeners to items
items.forEach(item => {
    item.addEventListener('click', (event) => {
        // Prevent default navigation for testing purposes
        event.preventDefault();

        sessionStorage.setItem('activePage', item.href);
        location.href = item.href

        // Update the active class
        items.forEach(el => el.classList.remove('Active'));
        item.classList.add('Active');
    });
});



var pfp = document.getElementById('pfp');
pfp.addEventListener('click', () => {
    var fileInput = document.createElement('input');
    fileInput.setAttribute('type', 'file');
    fileInput.setAttribute('accept', '.jpg,.jpeg,.png');
    fileInput.setAttribute('name', 'pfp');
    
    fileInput.click();
    
    fileInput.addEventListener('change', () => {
        var file = fileInput.files[0];
        if (file) {
            var formData = new FormData();
            formData.append('pfp', file);

            fetch('upload.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Profile picture uploaded successfully!');
                    location.reload()
                } else {
                    alert('Error uploading profile picture.');
                }
            })
        }
    });
});
        var menu = document.getElementById('menu');
         var sidebar = document.getElementById('sidebar')
         
         menu.addEventListener('click',()=>{
            if(sidebar.style.left == '-300px'){
                sidebar.style.left = '0px'
            }
            else{
                sidebar.style.left = '-300px'
            }
         })

</script>