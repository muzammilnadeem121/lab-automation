-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 25, 2024 at 09:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lab-automation`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `hire_date` date NOT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `first_name`, `last_name`, `email`, `phone_number`, `department`, `designation`, `hire_date`, `salary`, `created_at`, `status`) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '1234567890', 'IT', 'Software Engineer', '2023-06-15', 75000.00, '2024-12-15 08:24:39', 'Active'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '9876543210', 'HR', 'HR Manager', '2021-03-01', 65000.00, '2024-12-15 08:24:39', 'Active'),
(3, 'Mike', 'Brown', 'mike.brown@example.com', '5556667777', 'Finance', 'Accountant', '2020-11-20', 55000.00, '2024-12-15 08:24:39', 'Active'),
(4, 'Sarah', 'Johnson', 'sarah.johnson@example.com', '4443332222', 'IT', 'Data Analyst', '2022-01-10', 72000.00, '2024-12-15 08:24:39', 'Active'),
(5, 'Emma', 'Williams', 'emma.williams@example.com', '9998887777', 'Marketing', 'Marketing Specialist', '2024-05-01', 48000.00, '2024-12-15 08:24:39', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `subject`, `message`, `submitted_at`) VALUES
(1, 'Muzammil Nadeem', 'nadeemiqbal2611@gmail.com', 'Mail from Lab-automation', 'Just Testing !!! Ignore This Message.', '2024-12-23 16:26:54');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(10) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `revision` varchar(50) DEFAULT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `revision`, `manufacturing_date`, `description`, `created_at`) VALUES
('1000000001', 'Smartphone', 'A1', '2024-01-15', 'Latest model with advanced features', '2024-12-14 19:00:00'),
('1000000002', 'Laptop Pro', 'B3', '2024-02-20', 'High-performance laptop for professionals', '2024-12-14 19:00:00'),
('1000000003', 'Wireless Earbuds', 'C2', '2024-03-10', 'Noise-cancelling and waterproof', '2024-12-14 19:00:00'),
('1000000004', '4K TV', 'D1', '2024-04-05', 'Ultra HD with smart features', '2024-12-14 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `product_id` varchar(10) DEFAULT NULL,
  `test_type` varchar(100) NOT NULL,
  `criteria` text NOT NULL,
  `output` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('Passed','Failed','Pending') NOT NULL,
  `tested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `tested_by` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `test_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`product_id`, `test_type`, `criteria`, `output`, `remarks`, `status`, `tested_at`, `tested_by`, `user_id`, `test_id`) VALUES
('1000000001', 'Functionality', 'Battery life > 10 hrs', '12 hrs', 'Battery exceeded expectations', 'Passed', '2024-12-13 19:00:00', NULL, NULL, 1),
('1000000002', 'Performance', 'Boot time < 10 sec', '8 sec', 'System booted quickly', 'Passed', '2024-12-13 19:00:00', NULL, NULL, 2),
('1000000003', 'Durability', 'Drop test > 2m', '2.5m', 'Survived drop test', 'Passed', '2024-12-13 19:00:00', NULL, NULL, 3),
('1000000004', 'Display', 'Resolution 4K', '1080p', 'Resolution below standard', 'Failed', '2024-12-13 19:00:00', NULL, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password_hash`, `email`, `created_at`, `last_login`) VALUES
(1, 'johndoe', '$2y$10$G5mWlnIHYL4dnsJ6hxb.C.NBtf3XVL5ZXfqoD8fHaaD0BmShP2W4q', 'johndoe@gmail.com', '2024-12-15 15:18:21', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`test_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `tested_by` (`tested_by`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tests_ibfk_2` FOREIGN KEY (`tested_by`) REFERENCES `employees` (`employee_id`),
  ADD CONSTRAINT `tests_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
