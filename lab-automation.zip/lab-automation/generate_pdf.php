<?php
include 'db.php';
require 'fpdf/fpdf.php';

// Custom colors
define('HEADER_COLOR', [50, 50, 150]);
define('SUB_HEADER_COLOR', [100, 100, 250]);
define('TABLE_HEADER_COLOR', [200, 200, 255]);
define('TEXT_COLOR', [50, 50, 50]);

// Fetch data for the PDF report
$sql = "SELECT status, COUNT(*) AS count FROM tests GROUP BY status";
$result = $conn->query($sql);

$employees_sql = "SELECT * FROM employees WHERE 1";
$employees_result = $conn->query($employees_sql);

$users_sql = "SELECT * FROM users WHERE 1";
$users_result = $conn->query($users_sql);

// Create a new PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Set custom font and colors
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetTextColor(...HEADER_COLOR);

// Title
$pdf->Cell(0, 10, 'Lab Automation Report', 0, 1, 'C');
$pdf->Ln(10);

// Section: Overview
$pdf->SetTextColor(...SUB_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Overview', 0, 1, 'L');

$pdf->SetTextColor(...TEXT_COLOR);
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, "This report provides a comprehensive analysis of lab operations, including test statistics, employee and user data, and system performance. The lab automation system has enhanced efficiency and minimized errors. Below is a detailed breakdown of key metrics.");
$pdf->Ln(10);

// Section: Test Statistics
$pdf->SetTextColor(...SUB_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Test Statistics', 0, 1, 'L');
$pdf->Ln(5);

// Table header for test statistics
$pdf->SetFillColor(...TABLE_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(100, 10, 'Test Status', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Total', 1, 1, 'C', true);

// Table rows for test statistics
$pdf->SetFont('Arial', '', 12);
while ($row = $result->fetch_assoc()) {
    $pdf->SetTextColor(...TEXT_COLOR);
    $pdf->Cell(100, 10, ucfirst($row['status']), 1);
    $pdf->Cell(50, 10, $row['count'], 1, 1, 'C');
}
$pdf->Ln(10);

// Section: Employee Details
$pdf->SetTextColor(...SUB_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Employee Details', 0, 1, 'L');
$pdf->Ln(5);

// Employee data table
$pdf->SetFillColor(...TABLE_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(70, 10, 'Name', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Position', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Joined', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 12);
while ($row = $employees_result->fetch_assoc()) {
    $pdf->SetTextColor(...TEXT_COLOR);
    $pdf->Cell(70, 10, $row['first_name'] . " " . $row['last_name'], 1);
    $pdf->Cell(50, 10, $row['designation'], 1);
    $pdf->Cell(40, 10, date('d M Y', strtotime($row['hire_date'])), 1, 1);
}
$pdf->Ln(10);

// Section: User Statistics
$pdf->SetTextColor(...SUB_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'User Statistics', 0, 1, 'L');
$pdf->Ln(5);

// User data table
$pdf->SetFillColor(...TABLE_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(70, 10, 'Name', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Email', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Registered', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 12);
while ($row = $users_result->fetch_assoc()) {
    $pdf->SetTextColor(...TEXT_COLOR);
    $pdf->Cell(70, 10, $row['username'], 1);
    $pdf->Cell(50, 10, $row['email'], 1);
    $pdf->Cell(40, 10, date('d M Y', strtotime($row['created_at'])), 1, 1);
}
$pdf->Ln(10);
$pdf->Ln(10);

// Summary Section
$pdf->SetTextColor(...SUB_HEADER_COLOR);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Summary', 0, 1, 'L');

$pdf->SetTextColor(...TEXT_COLOR);
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, "The lab automation system has handled an impressive number of tests with minimal errors. The dedicated employees and registered users have contributed significantly to the system's overall efficiency. Continuous improvements are being implemented to enhance the system's capabilities further.");
$pdf->Ln(10);

$pdf->Output('D', 'Lab_Automation_Report.pdf');
?>
