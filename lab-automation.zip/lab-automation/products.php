<?php include 'redirect.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Lab Automation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=light_mode" />
    <?php
        include 'db.php';
        $products_sql = "SELECT * FROM products WHERE 1";
        $products_result = $conn->query($products_sql);

        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $input = $_GET['search'];

            $products_sql = "SELECT * FROM `products` WHERE `product_name` LIKE '%$input%'";
            $products_result = $conn->query($products_sql);
        }
    ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            margin: 100px 20px 20px 300px;
            flex-grow: 1;
            padding: 15px;
            background-color: #f4f4f9;
            overflow-x: hidden;
        }
        .card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        .dashboard {
        display: flex;
    }

/* Sidebar */
.sidebar {
    width: 250px;
    background-color: #ffffff;
    padding: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    align-content: center;
    height: 100%;
    top: 0;
    left: 0;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bolder;
    padding: 10px 12px;
    display: block;
    transition: 0.2s linear;
}

.sidebar ul li a:hover {
    background-color: #007bff;
    border-radius: 7px;
    color: white;
}
.dashboard {
    display: flex;
}
p.log-out{
    width: 80%;
    margin: 10px 10px 10px 0px;
    position: absolute;
    bottom: 30px;
    color: #333;
    font-size: 17px;
    font-weight: bolder;
    padding: 10px 15px 10px 20px;
    transition: 0.2s linear;
    border-radius: 7px;
    cursor: pointer;
}
p.log-out:hover{
    background-color: #007bff;
    color: white;
}
.btn{
    background-color: #007bff;
    color: white;
    font-size: 15px;
    font-weight: bolder;
    cursor: pointer;
    padding: 10px;
    border: none;
    border-radius: 7px;
    transition: 0.2s ease-in-out;
}
.btn:hover{
  background-color: #0056b3;
}
form{
    padding: 5px;
}
.searchInput{
    width: 50%;
    height: 25px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline-color: #007bff;
    padding: 5px 10px;
    margin: 5px;
    font-size: 1rem;
}
.searchBtn{
    background-color: #007bff;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bolder;
    font-size: 1rem;
}
.action{
    background-color: #007bff;
    color: white;
    font-size: 15px;
    cursor: pointer;
    border: none;
    border-radius: 5px;
    padding: 5px 10px;
    transition: 0.3s background-color;
}
.action:hover{
    background-color: #0056b3;
}
.confirm-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      visibility: hidden;
      opacity: 0;
      transition: visibility 0s, opacity 0.3s ease;
    }

    .confirm-box {
      background-color: white;
      border-radius: 10px;
      width: 300px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }

    .confirm-box h3 {
      color: #007bff;
      margin-bottom: 15px;
    }

    .confirm-box p {
      margin-bottom: 20px;
      color: #333;
    }

    .confirm-box .btn {
      padding: 10px 15px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      transition: 0.3s linear;
    }

    .btn-blue {
      background-color: #007bff;
      color: white;
    }

    .btn-blue:hover {
      background-color: #0056b3;
    }

    .btn-white {
      background-color: white;
      color: #007bff;
      border: 1px solid #007bff;
      margin-left: 10px;
    }

    .btn-white:hover {
      background-color: #f4f4f9;
    }

    .show {
      visibility: visible;
      opacity: 1;
    }
@media (max-width: 768px) {
    .sidebar {
        width: 200px;
    }
    .container {
        margin-left: 200px; 
    }
    .dashboard {
        flex-direction: column; 
    }
}

    </style>
</head>
<body>
<?php include 'header.php';?>
    <div class="dashboard">
    <?php include_once 'sidebar.php';?>
    <div class="container">
        <div class="card">
            <h2>Products</h2>
            <button class="btn" onClick="location.href = 'add_product.php'">Add a Product</button>
            <form action="" method="GET">
            <input placeholder="Search product name" type="text" name="search" class="searchInput">
            <input type="submit" value="Search" class="searchBtn">
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Version</th>
                        <th>MFG Date</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $products_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['product_name']; ?></td>
                            <td><?php echo $row['revision']; ?></td>
                            <td><?php echo $row['manufacturing_date']; ?></td>
                            <td><?php echo $row['description']; ?></td>
                            <td><a href="edit_product.php?id=<?php echo $row['product_id']?>"><button class="action"><i class="fa-solid fa-pen-to-square"></i> Edit</button></a> <button class="action" data-href="delete_product.php?id=<?php echo $row['product_id'];?>" id="deleteProductBtn"><i class="fa-solid fa-trash"></i> Delete</button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
    <div class="confirm-overlay" id="confirmOverlay">
    <div class="confirm-box">
      <h3>Confirm Action</h3>
      <p>Are you sure you want to proceed?</p>
      <button class="btn btn-blue" id="confirmYes">Yes</button>
      <button class="btn btn-white" id="confirmNo">No</button>
    </div>
  </div>
</body>
<script>
    var btn = document.querySelectorAll('#deleteProductBtn');
    var confirmOverlay = document.getElementById('confirmOverlay');
    var confirmYes = document.getElementById('confirmYes');
    var confirmNo = document.getElementById('confirmNo');
    var targetHref = ''; 

btn.forEach(element => {        
    element.addEventListener('click', () => {
        targetHref = element.dataset.href; 
        confirmOverlay.classList.add('show');
    });
});

confirmYes.addEventListener('click', () => {
    confirmOverlay.classList.remove('show');
    if (targetHref) {
        location.href = targetHref; 
    }
});

confirmNo.addEventListener('click', () => {
    confirmOverlay.classList.remove('show');
    targetHref = '';
});
</script>
</html>