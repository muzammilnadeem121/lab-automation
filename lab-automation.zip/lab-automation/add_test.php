<?php
$error = $success = '';

include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $test_type = $_POST['test_type'];
    $test_product = $_POST['test_product'];
    $test_date = $_POST['test_date'];

    $sql = "SELECT 'product_id' FROM `products` WHERE `product_name`='$test_product'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $sql = "SELECT * FROM `tests` WHERE `product_id`='$row' AND `status`='Pending'";
    $result = $conn->query($sql);
    if($result->num_rows < 1){
    
        $sql = "INSERT INTO tests (test_type, product_id, tested_at,user_id) VALUES ($test_type, $row, $test_date,".$_SESSION['user_id'].")";
        if($conn->query($sql) === TRUE){
            $success = 'Product added Successfuly';
        }else{
            $error = "Error : $conn->error";
        }
    }else{
        $error = "Product is Already being used in a test";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Test</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input{
            outline-color: #007bff;
            outline-width: 1px;
        }
        input, select, button {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            transition: 0.3s linear;
            background-color: #007bff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .msg{
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            padding: 10px;
            display: none;
        }
        a.back{
            text-decoration: none;
            color: white;
            width: max-content;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Test</h1>
        <form action="add_test.php" method="POST">
            <div class="msg" id="msg">
                <p><?php if($error){ echo $error;} else if($success){echo $success;header('Location: tests.php');}?><p>
            </div>
            <a class="back" href="tests.php"><button type="button"><i class="fa-solid fa-arrow-left"></i> Back</button></a>
            <label for="test_type">Test Type:</label>
            <input type="text" id="test_type" name="test_type" required autofocus>

            <label for="test_product">Test Product:</label>
            <input type="text" id="test_product" name="test_product" required>

            <label for="test_date">Test Date:</label>
            <input type="datetime-local" id="test_date" name="test_date" required>

            <button type="submit">Add Test</button>
        </form>
    </div>
</body>
</html>
