<?php include 'redirect.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tests Overview - Lab Automation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=light_mode" />
    <?php
        include 'db.php';
        
        $tests_sql = "SELECT * FROM tests WHERE 1";
        $tests_result = $conn->query($tests_sql);

        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $input = $_GET['search'];

            $tests_sql = "SELECT * FROM `tests` WHERE `test_type` LIKE '%$input%'";
            $tests_result = $conn->query($tests_sql);
        }
    ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            margin: 80px 20px 20px 300px;
            flex-grow: 1;
            padding: 15px;
            background-color: #f4f4f9;
            overflow-x: hidden;
        }
        .card {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        .dashboard {
        display: flex;
    }

/* Sidebar */
.sidebar {
    width: 250px;
    background-color: #ffffff;
    padding: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    align-content: center;
    height: 100%;
    top: 0;
    left: 0;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 10px 0;
}

.sidebar ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bolder;
    padding: 10px 12px;
    display: block;
    transition: 0.2s linear;
}

.sidebar ul li a:hover {
    background-color: #007bff;
    border-radius: 7px;
    color: white;
}

.dashboard {
    display: flex;
}
p.log-out{
    width: 75%;
    margin: 10px 10px 10px 10px;
    position: absolute;
    bottom: 30px;
    color: #333;
    font-size: 17px;
    font-weight: bolder;
    padding: 10px 15px 10px 20px;
    transition: 0.2s linear;
    border-radius: 7px;
    cursor: pointer;
}
p.log-out:hover{
    background-color: #007bff;
    color: white;
}
.btn{
    background-color: #007bff;
    color: white;
    font-weight: bolder;
    font-size: 15px;
    border: none;
    border-radius: 7px;
    padding: 10px;
    cursor: pointer;
    transition: 0.2s ease-in-out;
}
.btn:hover{
    background-color: #0056b3;
}
form{
    padding: 5px;
}
.searchInput{
    width: 50%;
    height: 25px;
    border: 1px solid #ddd;
    border-radius: 5px;
    outline-color: #007bff;
    padding: 5px 10px;
    margin: 5px;
    font-size: 1rem;
}
.searchBtn{
    background-color: #007bff;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bolder;
    font-size: 1rem;
}
.action{
    background-color: #007bff;
    color: white;
    font-size: 15px;
    cursor: pointer;
    border: none;
    border-radius: 5px;
    padding: 5px 10px;
    transition: 0.3s background-color;
}
.action:hover{
    background-color: #0056b3;
}
.confirm-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      visibility: hidden;
      opacity: 0;
      transition: visibility 0s, opacity 0.3s ease;
    }

    .confirm-box {
      background-color: white;
      border-radius: 10px;
      width: 300px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }

    .confirm-box h3 {
      color: #007bff;
      margin-bottom: 15px;
    }

    .confirm-box p {
      margin-bottom: 20px;
      color: #333;
    }

    .confirm-box .btn {
      padding: 10px 15px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      transition: 0.3s linear;
    }

    .btn-blue {
      background-color: #007bff;
      color: white;
    }

    .btn-blue:hover {
      background-color: #0056b3;
    }

    .btn-white {
      background-color: white;
      color: #007bff;
      border: 1px solid #007bff;
      margin-left: 10px;
    }

    .btn-white:hover {
      background-color: #f4f4f9;
    }

    .show {
      visibility: visible;
      opacity: 1;
    }
@media (max-width: 768px) {
    .sidebar {
        width: 200px;
    }
    .container {
        margin-left: 200px; 
    }
    .dashboard {
        flex-direction: column; 
    }
}
    </style>
</head>
<body>
<?php include 'header.php';?>
    <div class="dashboard">
    <?php include_once 'sidebar.php';?>
    <div class="container">
        <div class="card">
            <h2>Tests Overview</h2>
            <button class="btn" onclick="location.href='add_test.php'"><strong>Perform a Test</strong></button>
            <form action="" method="GET">
            <input placeholder="Search Test Name" type="text" name="search" class="searchInput">
            <input type="submit" value="Search" class="searchBtn">
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Test Name</th>
                        <th>Product</th>
                        <th>Criteria</th>
                        <th>Status</th>
                        <th>Tested At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
    <?php while ($row = $tests_result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $row['test_type']; ?> test</td>
        <td>
            <?php 
                $product_sql = "SELECT product_name FROM products WHERE product_id = " . $row['product_id'];
                $product_result = $conn->query($product_sql);
                if ($product_result->num_rows > 0) {
                    $product_row = $product_result->fetch_assoc();
                    echo $product_row['product_name'];
                }
            ?>
        </td>
        <td><?php echo $row['criteria']; ?></td>
        <td><?php echo $row['status']; ?></td>
        <td><?php echo $row['tested_at']; ?></td>
        <td><a href="edit_test.php?id=<?php echo $row['test_id']?>"><button class="action"><i class="fa-solid fa-pen-to-square"></i> Edit</button></a> <button class="action" data-href="delete_test.php?id=<?php echo $row['test_id'];?>" id="deleteTestBtn"><i class="fa-solid fa-trash"></i> Delete</button></td>
    </tr>
<?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
    <div class="confirm-overlay" id="confirmOverlay">
    <div class="confirm-box">
      <h3>Confirm Action</h3>
      <p>Are you sure you want to proceed?</p>
      <button class="btn btn-blue" id="confirmYes">Yes</button>
      <button class="btn btn-white" id="confirmNo">No</button>
    </div>
  </div>
</body>
</html>
<script>
    var btn = document.querySelectorAll('#deleteTestBtn');
    var confirmOverlay = document.getElementById('confirmOverlay');
    var confirmYes = document.getElementById('confirmYes');
    var confirmNo = document.getElementById('confirmNo');
    var targetHref = ''; 

btn.forEach(element => {        
    element.addEventListener('click', () => {
        targetHref = element.dataset.href; 
        confirmOverlay.classList.add('show');
    });
});

confirmYes.addEventListener('click', () => {
    confirmOverlay.classList.remove('show');
    if (targetHref) {
        location.href = targetHref; 
    }
});

confirmNo.addEventListener('click', () => {
    confirmOverlay.classList.remove('show');
    targetHref = '';
});
</script>