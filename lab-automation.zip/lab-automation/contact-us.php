<?php

$success = $error = '';
include_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);

    if ($stmt->execute()) {
        $success = "Thanks for Your feedback!";
    } else {
        $error = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <?php include 'links.php'; ?>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
        }
        .contact-container {
            margin-top: 80px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            padding: 20px;
            gap: 20px;
        }
        .contact-form, .contact-map {
            width: 100%;
            max-width: 45%;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
        }
        .contact-form h2 {
            margin-bottom: 20px;
            color: #007bff;
        }
        .contact-form input,
        .contact-form textarea,
        .contact-form button {
            width: 90%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
            outline-color: #007bff;
        }
        .contact-form textarea {
            height: 120px;
            resize: none;
        }
        .contact-form button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .contact-form button:hover {
            background-color: rgb(0, 105, 218);
        }
        .contact-map iframe {
            width: 100%;
            height: 400px;
            border: 0;
            border-radius: 8px;
        }
        .success{
            color: green;
        }
        .error{
            color: red;
        }
        @media (max-width: 768px) {
            .contact-form, .contact-map {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="contact-container">
        <div class="contact-form">
            <h2>Contact Us</h2>
            <form action="" method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="subject" placeholder="Subject" required>
                <textarea name="message" placeholder="Your Message" required></textarea>
                <button type="submit">Send Message</button>
                <p class="success"><?php if($success) echo $success;?></p>
                <p class="error"><?php if($error) echo $error;?></p>
            </form>
        </div>
        <div class="contact-map">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345086204!2d144.95543131531002!3d-37.81720944201438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf577b0c799d00256!2sMelbourne%20CBD%2C%20VIC%2C%20Australia!5e0!3m2!1sen!2s!4v1678173054674!5m2!1sen!2s" 
                allowfullscreen 
                loading="lazy">
            </iframe>
        </div>
    </div>
</body>
</html>