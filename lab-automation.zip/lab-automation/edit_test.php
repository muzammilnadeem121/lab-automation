<?php
include 'db.php';
session_start();

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $test_id = $_GET['id'];
    $_SESSION['test_id'] = $test_id;

    $sql = "SELECT * FROM `tests` WHERE `test_id`='$test_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $sql = "SELECT product_name FROM `products` WHERE `product_id`='" . $row['product_id'] . "'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $test_id = $_SESSION['test_id']; // Retrieve test ID from session
    $test_type = $_POST['test_type'];
    $test_product = $_POST['test_product'];
    $test_date = $_POST['test_date'];

    // Validate product name
    $sql = "SELECT product_name FROM `products` WHERE `product_name` = '$test_product'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die('No product found with that Name');
    }

    // Update test details
    $sql = "UPDATE `tests` SET `test_type` = '$test_type', `product_id` = (SELECT `product_id` FROM `products` WHERE `product_name` = '$test_product'), `tested_at` = '$test_date' WHERE `test_id` = '$test_id'";
    $result = $conn->query($sql);

    if ($conn->error) {
        $error = "Error: " . $conn->error;
    } else {
        $success = "Test updated successfully!";
        header("Location: tests.php");
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Test</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input{
            outline-color: #007bff;
            outline-width: 1px;
        }
        input, select, button {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            transition: 0.3s linear;
            background-color: #007bff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .msg{
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            padding: 10px;
            display: none;
        }
        a.back{
            text-decoration: none;
            color: white;
            width: max-content;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Test</h1>
        <form action="edit_test.php" method="POST">
            <div class="msg" id="msg">
                <p><?php if($error){ echo $error;} else if($success){echo $success;header('Location: tests.php');}?><p>
            </div>
            <a class="back" href="tests.php"><button type="button"><i class="fa-solid fa-arrow-left"></i> Back</button></a>
            <label for="test_type">Test Type:</label>
            <input type="text" id="test_type" name="test_type" required autofocus value="<?php echo $row['test_type'];?>">

            <label for="test_product">Test Product:</label>
            <input type="text" id="test_product" name="test_product" required value="<?php echo $product['product_name'];?>">

            <label for="test_date">Test Date:</label>
            <input type="datetime-local" id="test_date" name="test_date" required value="<?php echo $row['tested_at'];?>">

            <button type="submit">Edit Test</button>
        </form>
    </div>
</body>
</html>