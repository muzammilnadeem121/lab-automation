<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Automation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }
        .hero {
            position: relative;
            background-image: url('hero.jpg');
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            color: white;
            height: 450px;
            padding: 50px 20px;
            margin-top: 60px;
            text-align: center;
            align-content: center;
        }
        .hero h2 {
            z-index: 1;
            position: relative;
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .hero p {
            z-index: 1;
            position: relative;
            font-size: 1.2rem;
            margin-bottom: 30px;
            text-shadow: 4px 4px 14px white;
        }
        .hero button {
            z-index: 1;
            position: relative;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .hero button:hover {
            background-color:rgb(0, 105, 218);
        }
        .features {
            padding: 40px 20px;
            text-align: center;
            background-color: #f4f4f9;
        }
        .features h2 {
            margin-bottom: 30px;
            color: #007bff;
        }
        .features .feature-list {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }
        .features .feature-item {
            width: 25%;
            cursor: pointer;
            min-width: 200px;
            margin-bottom: 20px;
            background: white;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            line-height: 20px;
            transition: 0.2s linear;
        }
        .features .feature-item:hover {
            transform: scale(1.1); 
        }
        .features .feature-item i {
            font-size: 2rem;
            color: #007bff;
            margin-bottom: 10px;
        }
        .features .feature-item h3 {
            margin: 10px 0;
            font-size: 1.2rem;
        }
        .shadow{
            height: 100%;
            width: 100%;
            position: absolute;
            background-color:rgba(0, 0, 0, 0.45);
            top: 0px;
            left: 0px;
        }
        .testimonials {
        background-color: #fff;
        padding: 40px 20px;
        text-align: center;
    }
    .testimonials h2 {
        margin-bottom: 30px;
        color: #007bff;
    }
    .testimonial-list {
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }
    .testimonial-item {
        max-width: 30%;
        margin: 10px;
        padding: 20px;
        background: #f4f4f9;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .testimonial-item p {
        font-size: 1rem;
        color: #555;
        margin-bottom: 15px;
    }
    .testimonial-item h4 {
        font-size: 1.2rem;
        color: #007bff;
    }
    .testimonial-item div{
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
    }
    .faq {
    background-color: #f4f4f9;
}

.faq h2 {
    text-align: center;
    color: #007bff;
    margin-bottom: 20px;
}
.faq-container{
    background-color: white;
    padding: 40px 20px;
    max-width: 800px;
    margin: 30px auto;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.faq-item {
    border-bottom: 1px solid #ddd;
    padding: 15px 0;
}

.faq-question {
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
}

.faq-question h3 {
    margin: 0;
    font-size: 1.2rem;
    color: #333;
}

.faq-question i {
    font-size: 1.2rem;
    color: #007bff;
    transition: transform 0.3s;
}

.faq-answer {
    display: none;
    padding: 10px 0;
    color: #555;
    font-size: 1rem;
    line-height: 1.5;
    transition: 0.3s opacity;
}

    .faq-item.open .faq-answer {
    display: block;
    }
    .faq-item.open .faq-question i {
    transform: rotate(225deg); /* Change "+" to "x" */
    }
    .img{
        height: 40px;
        width: 40px;
        border-radius: 100%;
        background-image: url('p-1.jpg');
        background-position: center;
        background-size: cover;
        display: inline-flex;
    }
    .contact-us {
    position: relative;
    background-image: url('p-2.webp');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    color: white;
    height: 300px;
    padding: 50px 20px;
    margin-top: 40px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

.contact-us h2 {
    z-index: 1;
    position: relative;
    font-size: 2rem;
    margin-bottom: 10px;
}

.contact-us p {
    z-index: 1;
    position: relative;
    font-size: 1.2rem;
    margin-bottom: 20px;
}

.contact-us button {
    z-index: 1;
    position: relative;
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 1rem;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.contact-us button:hover {
    background-color: rgb(0, 105, 218);
}
    </style>
</head>
<body>
    <?php include 'header.php';?>
    <section class="hero">
        <div class="shadow"></div>
        <h2>Revolutionize Your Lab Operations</h2>
        <p>With Lab Automation, managing tests, products, and reports is simpler than ever.</p>
        <button onclick="location.href='sign-up.php'">Get Started</button>
    </section>
    <section class="features" id="features">
        <h2>Our Features</h2>
        <div class="feature-list">
            <div class="feature-item">
                <i class="fas fa-tasks"></i>
                <h3>Manage Tests</h3>
                <p>Easily track, organize, and monitor all your test data in one streamlined platform, ensuring efficient management and accessibility at any time.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-box"></i>
                <h3>Inventory Management</h3>
                <p>Effortlessly keep track of your products, supplies, and lab essentials, ensuring nothing falls through the cracks with real-time inventory updates.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-chart-line"></i>
                <h3>Generate Reports</h3>
                <p>Quickly create detailed, professional, and accurate lab reports, simplifying data analysis and sharing insights with your team.</p>
            </div>
        </div>
    </section>
    <section class="testimonials">
    <h2>What Our Users Say</h2>
    <div class="testimonial-list">
        <div class="testimonial-item">
            <p><strong style="font-size:24px">"</strong>Lab Automation has completely transformed how we manage our lab. It's efficient and user-friendly!<strong style="font-size:24px">"</strong></p>
            <div><div class="img"></div><h4> Dr. Alice Johnson</h4></div>
        </div>
        <div class="testimonial-item">
            <p><strong style="font-size:24px">"</strong>Managing inventory has never been this easy. Highly recommend this tool!<strong style="font-size:24px">"</strong></p>
            <div><div class="img"></div><h4> Lab Manager, Mark Thompson</h4></div>
        </div>
        <div class="testimonial-item">
            <p><strong style="font-size:24px">"</strong>The reporting features are top-notch, saving us hours of work every week.<strong style="font-size:24px">"</strong></p>
            <div><div class="img"></div><h4> Sarah Lee, Analyst</h4></div>
        </div>
    </div>
</section>
<section  class="faq">
<div class="faq-container">
    <h2>Frequently Asked Questions</h2>
    <div class="faq-item">
        <div class="faq-question">
            <h3>How secure is my data?</h3>
            <i class="fas fa-plus"></i>
        </div>
        <div class="faq-answer">
            <p><strong>Ans: </strong>We prioritize your privacy and use the latest encryption technologies to protect your data.</p>
        </div>
    </div>
    <div class="faq-item">
        <div class="faq-question">
            <h3>Can I customize features?</h3>
            <i class="fas fa-plus"></i>
        </div>
        <div class="faq-answer">
            <p><strong>Ans: </strong>Yes, our platform is flexible and can be tailored to meet your specific lab needs.</p>
        </div>
    </div>
    <div class="faq-item">
        <div class="faq-question">
            <h3>Do you offer customer support?</h3>
            <i class="fas fa-plus"></i>
        </div>
        <div class="faq-answer">
            <p><strong>Ans: </strong>Absolutely! Our dedicated support team is available 24/7 to assist you.</p>
        </div>
    </div>
</div>
</section>
<section class="contact-us">
    <div class="shadow"></div>
    <h2>Get in Touch</h2>
    <p>Have questions or need assistance? We're here to help!</p>
    <button onclick="location.href='contact-us.php'">Contact Us</button>
</section>
    <?php include 'footer.php';?>
</body>
<script>
    document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        const faqItem = question.parentElement;
        const isOpen = faqItem.classList.contains('open');

        // Close all open items
        document.querySelectorAll('.faq-item.open').forEach(item => {
            item.classList.remove('open');
        });

        // Toggle the clicked item
        if (!isOpen) {
            faqItem.classList.add('open');
        }
    });
});
</script>
</html>
