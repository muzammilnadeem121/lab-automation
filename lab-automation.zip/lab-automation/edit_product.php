<?php
include 'db.php';
session_start();

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $product_id = $_GET['id'];
    $_SESSION['product_id'] = $product_id;

    $sql = "SELECT * FROM `products` WHERE `product_id`='$product_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_SESSION['product_id'];
    $product_name = $_POST['product_name'];
    $product_version = $_POST['product_version'];
    $product_date = $_POST['product_date'];
    $product_desc = $_POST['product_desc'];

    $sql = "UPDATE `products` SET `product_name` = '$product_name', `revision` = '$product_version',`manufacturing_date` = '$product_date',`description` = '$product_desc'  WHERE `product_id` = '$product_id'";
    $result = $conn->query($sql);

    if ($conn->error) {
        $error = "Error: " . $conn->error;
    } else {
        $success = "Product updated successfully!";
        header("Location: products.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Test</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input{
            outline-color: #007bff;
            outline-width: 1px;
        }
        input, select, button {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            transition: 0.3s linear;
            background-color: #007bff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .msg{
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            padding: 10px;
            display: none;
        }
        a.back{
            text-decoration: none;
            color: white;
            width: max-content;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Test</h1>
        <form action="" method="POST">
            <div class="msg" id="msg">
                <p><?php if($error){ echo $error;} else if($success){echo $success;header('Location: products.php');}?><p>
            </div>
            <a class="back" href="products.php"><button type="button"><i class="fa-solid fa-arrow-left"></i> Back</button></a>
            <label for="test_type">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required autofocus value="<?php echo $row['product_name'];?>">

            <label for="test_product">Product Version:</label>
            <input type="text" id="product_version" name="product_version" required value="<?php echo $row['revision'];?>">

            <label for="test_date">Manufacturing Date:</label>
            <input type="date" id="product_date" name="product_date" required value="<?php echo $row['manufacturing_date'];?>">

            <label for="test_date">Product Description:</label>
            <input type="text" id="product_desc" name="product_desc" required value="<?php echo $row['description'];?>">
            
            <button type="submit">Edit Product</button>
        </form>
    </div>
</body>
</html>