<?php
// Database connection
include 'db.php';
session_start();
$error = $success = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt the password

    $sql = "SELECT * FROM `users` WHERE `username`='$username'";
    $result = $conn->query($sql);
    if($result->num_rows < 1){        
        $sql = "INSERT INTO users (username, email, password_hash, created_at) VALUES ('$username', '$email', '$password', NOW())";
        if ($conn->query($sql) === TRUE) {
            $success = "Account created successfully!";
    
            $sql = "SELECT * FROM `users` WHERE `username`='$username'";
            $result = $conn->query($sql);
            $user = $result->fetch_assoc();
    
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $_POST['username'];
            
            header('Location : dashboard.php');
        } else {
            $error = "Error: $conn->error";
        }
    }else{
        $error = "Account Already Exists";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        form label {
            display: block;
            margin: 10px 0 5px;
            color: #555;
        }
        form input {
            width: 90%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            color: #333;
            margin-bottom: 20px;
        }
        form input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        form button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s;
            width: 100%;
            font-size: 15px;
            font-weight: bolder;
        }
        form button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 10px;
            text-align: center;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
        .footer {
            margin-top: 20px;
            font-size: 0.9rem;
            width: 100%;
            text-align: center;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        .footer a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Create an Account</h2>
        <form method="POST" action="">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder="Enter your username" required>
            
            <label for="email">Email</label>
            <input type="email" name="email" id="email" placeholder="Enter your email" required>
            
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Enter your password" required>
            
            <button type="submit">Create Account</button>
        </form>
        <div class="message">
            <?php if ($success) echo "<p class='success'>$success</p>"; ?>
            <?php if ($error) echo "<p class='error'>$error</p>"; ?>
        </div>
        <div class="footer">
        <strong><span>Already have an account? <a href="login.php">Login here</a></span></strong>
        </div>
    </div>
</body>
</html>
