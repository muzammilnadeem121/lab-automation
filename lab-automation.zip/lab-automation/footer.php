<style>
    footer {
            background: #007bff;
            color: white;
            text-align: center;
            padding: 20px 10px;
            display :flex;
            justify-content: space-between;
        }
        footer a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        footer a:hover {
            text-decoration: underline;
        }
        .social-icons{
            display: flex;
            justify-content: space-around;
            align-items: center;
            gap: 10px;
            padding: 0px 15px;
        }
        .icon{
            width: 40px;
            height: 40px;
            border-radius: 100%;
            background-color: white;
            text-align: center;
            align-content: center;
            cursor: pointer;
            font-size: 24px;
            transition: 0.2s ease;
        }
        .icon:hover{
            scale: 1.3;
        }
        .icon a{
            color: #007bff;
        }
</style>
<footer>
        <div>
        <p>&copy; 2024 Lab Automation. All rights reserved. <a href="#">Privacy Policy</a></p>
        </div>
        <div class="social-icons">
            <div class="icon">
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="icon">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            </div>
            <div class="icon">
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
            </div>
        </div>
</footer>