<style>
    header {
            width: 100%;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            z-index: 2;
            position: fixed;
            top: 0px;
            background-color: #007bff;
            margin-bottom: 150px;
        }
        .brand{
            cursor: pointer;
            padding: 5px;
            font-size: calc(20px + 1vw);
            font-weight: bold;
        }
        header p {
            margin: 5px 0 0;
            font-size: calc(5px + 0.5vw);
        }
        .menu{
            font-size: 24px;
            color: white;
            margin: 10px;
            padding: 10px;
            cursor: pointer;
            display: none;
        }
        a{
            text-decoration: none;
            color: white
        }
        @media(max-width : 900px){
            .menu{
                display: block;
            }
        }
</style>
<header id="navBar">
        <div class="brand">
            <a href="index.php">
                <i class="fa-solid fa-flask"></i>
                <span>Lab Automation</span>
                <p>Stream line Your Lab proceses Efficiently</p>
        </a>
        </div>
        <div class="menu" id="menu">
            <i class="fa-solid fa-bars"></i>
        </div>
</header>
<script>
         
</script>