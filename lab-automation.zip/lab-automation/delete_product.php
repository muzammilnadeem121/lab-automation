<?php
include 'db.php';

    $product_id = $_GET['id'];

    $sql = "DELETE FROM `products` WHERE `product_id`='$product_id'";
    $result = $conn->query($sql);
    if ($conn->error) {
        die('An unexpected Error Occured');
    }else{
        header('Location: products.php');
    }
?>